@echo off
title ANG TRANSMISSAO
cls

:: Localiza o executavel do Microsoft Edge (motor Chromium nativo de baixo consumo de RAM)
set "EDGE_PATH=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
if not exist "%EDGE_PATH%" set "EDGE_PATH=C:\Program Files\Microsoft\Edge\Application\msedge.exe"

set "APP_URL=https://transmissao.jogueang.com"
set "USER_DATA=%LOCALAPPDATA%\ANG_Transmissao\Profile"

:: Inicia em modo App isolado ultra-leve (sem barra de URL, sem extensoes pesadas e com icones customizados)
start "" "%EDGE_PATH%" --app="%APP_URL%" --user-data-dir="%USER_DATA%" --window-size=1280,760 --disable-extensions --disable-background-networking --disable-sync
exit
