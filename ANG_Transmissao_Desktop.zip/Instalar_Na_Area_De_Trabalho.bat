@echo off
title Instalador ANG Transmissao
cls
echo ===================================================
echo       INSTALADOR OFICIAL ANG TRANSMISSAO
echo ===================================================
echo.
echo Criando atalho na Area de Trabalho...

set "DEST_DIR=%LOCALAPPDATA%\ANG_Transmissao_App"
if not exist "%DEST_DIR%" mkdir "%DEST_DIR%"

copy /y "%~dp0app.ico" "%DEST_DIR%\app.ico" >nul
copy /y "%~dp0Iniciar_ANG_Transmissao.bat" "%DEST_DIR%\Iniciar_ANG_Transmissao.bat" >nul

:: Criar atalho no Desktop do usuario
echo Set oWS = WScript.CreateObject("WScript.Shell") > "%TEMP%\create_desktop_lnk.vbs"
echo sLinkFile = oWS.SpecialFolders("Desktop") ^& "\ANG Transmissao.lnk" >> "%TEMP%\create_desktop_lnk.vbs"
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> "%TEMP%\create_desktop_lnk.vbs"
echo oLink.TargetPath = "%DEST_DIR%\Iniciar_ANG_Transmissao.bat" >> "%TEMP%\create_desktop_lnk.vbs"
echo oLink.WorkingDirectory = "%DEST_DIR%" >> "%TEMP%\create_desktop_lnk.vbs"
echo oLink.IconLocation = "%DEST_DIR%\app.ico" >> "%TEMP%\create_desktop_lnk.vbs"
echo oLink.WindowStyle = 7 >> "%TEMP%\create_desktop_lnk.vbs"
echo oLink.Save >> "%TEMP%\create_desktop_lnk.vbs"

cscript //nologo "%TEMP%\create_desktop_lnk.vbs"
del "%TEMP%\create_desktop_lnk.vbs"

echo.
echo [SUCESSO] O atalho com o icone oficial foi adicionado a sua Area de Trabalho!
echo Voce ja pode abrir o app direto pelo atalho.
echo.
pause
